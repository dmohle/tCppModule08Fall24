//
// Created by BE129 on 11/25/2024.
//

#include <curl/curl.h>
#include <iostream>

int test_main03() {
    CURL *curl;
    CURLcode res;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if(curl) {
        // Set the URL
        curl_easy_setopt(curl, CURLOPT_URL, "https://example.com");

        // Set the CA certificate bundle
        curl_easy_setopt(curl, CURLOPT_CAINFO, "C:/2024_Fall/cit66_Cpp/chatBot01/cacert.pem");

        // Perform the request
        res = curl_easy_perform(curl);

        // Check for errors
        if(res != CURLE_OK) {
            std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
        }

        // Clean up
        curl_easy_cleanup(curl);
    }
    curl_global_cleanup();

    return 0;
}

